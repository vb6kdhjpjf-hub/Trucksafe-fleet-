import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata={title:"Trucksafe Fleet",description:"Truck-safe fleet navigation dashboard"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="he" dir="rtl"><body>{children}</body></html>}