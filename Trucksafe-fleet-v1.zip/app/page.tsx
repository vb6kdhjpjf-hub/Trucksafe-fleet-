 "use client";
import {useState} from "react";
import {Truck,Map,AlertTriangle,Navigation,Radio,ShieldCheck,Clock3,ChevronLeft} from "lucide-react";

const trips=[
{id:"TS-1042",driver:"דוד כהן",route:"טבריה → חיפה",status:"בנסיעה",eta:"10:42"},
{id:"TS-1043",driver:"יוסי לוי",route:"צפת → עפולה",status:"בנסיעה",eta:"11:18"},
{id:"TS-1044",driver:"אבי מזרחי",route:"כרמיאל → ירושלים",status:"ממתין",eta:"12:05"}];

export default function Home(){
 const [tab,setTab]=useState("dashboard"); const [safe,setSafe]=useState(true); const [alerts,setAlerts]=useState(true);
 return <main className="shell">
 <header className="topbar"><div><div className="brand">TRUCKSAFE <span>FLEET</span></div><div className="subtitle">מערכת ניהול וניווט בטוח למשאיות</div></div><div className="live"><i/> מערכת פעילה</div></header>
 <nav className="tabs">{[["dashboard","לוח בקרה"],["route","תכנון מסלול"],["fleet","צי רכב"],["alerts","התראות"]].map(([k,l])=><button key={k} className={tab===k?"active":""} onClick={()=>setTab(k)}>{l}</button>)}</nav>
 {tab==="dashboard"&&<><section className="hero"><div><p className="eyebrow">FLEET V1</p><h1>שלום, מנהל הצי</h1><p>שליטה במסלולים, נהגים והתראות בטיחות — במקום אחד.</p></div><button className="primary" onClick={()=>setTab("route")}><Navigation size={18}/> תכנן מסלול</button></section>
 <section className="stats"><Stat icon={<Truck/>} title="משאיות פעילות" value="12" note="+2 היום"/><Stat icon={<Navigation/>} title="נסיעות פעילות" value="8" note="2 מתחילות בקרוב"/><Stat icon={<ShieldCheck/>} title="נסיעות ללא אירוע" value="96%" note="30 ימים אחרונים"/><Stat icon={<AlertTriangle/>} title="התראות פתוחות" value="3" note="דורשות בדיקה"/></section>
 <section className="grid"><div className="panel"><div className="panelHead"><h2>מפת פעילות</h2><span>GPS חי</span></div><div className="map"><div className="road r1"/><div className="road r2"/><div className="road r3"/><Pin x="28%" y="38%" text="TS-1042"/><Pin x="61%" y="54%" text="TS-1043"/><Pin x="45%" y="72%" text="TS-1044"/><div className="mapLabel">אזור הצפון</div></div></div>
 <div className="panel"><div className="panelHead"><h2>נסיעות פעילות</h2><button className="link" onClick={()=>setTab("fleet")}>הצג הכל <ChevronLeft size={15}/></button></div><div className="tripList">{trips.map(t=><Trip key={t.id}{...t}/>)}</div></div></section>
 <section className="panel settings"><ShieldCheck size={22}/><div><b>מצב נהיגה בטוחה</b><small>מונע מסלולים עם מגבלות משאית ידועות</small></div><button className={safe?"toggle on":"toggle"} onClick={()=>setSafe(!safe)}><span/></button><Radio size={22}/><div><b>התראות בזמן אמת</b><small>התראות על מגבלות, סיכון ושינויים במסלול</small></div><button className={alerts?"toggle on":"toggle"} onClick={()=>setAlerts(!alerts)}><span/></button></section></>}
 {tab==="route"&&<RoutePlanner/>}{tab==="fleet"&&<Fleet/>}{tab==="alerts"&&<Alerts/>}
 </main>
}

function Stat({icon,title,value,note}:any){return <div className="stat"><div className="icon">{icon}</div><div><small>{title}</small><strong>{value}</strong><em>{note}</em></div></div>}
function Pin({x,y,text}:{x:string,y:string,text:string}){return <div className="pin" style={{left:x,top:y}}><span/><label>{text}</label></div>}
function Trip(p:any){return <div className="trip"><div className="truckIcon"><Truck size={18}/></div><div className="tripMain"><b>{p.id} · {p.driver}</b><span>{p.route}</span></div><div className="tripSide"><b>{p.eta}</b><small>{p.status}</small></div></div>}
function RoutePlanner(){return <section className="page"><div className="hero"><div><p className="eyebrow">SAFE ROUTE</p><h1>תכנון מסלול למשאית</h1><p>תכנון מסלול עם התחשבות במגבלות משאיות.</p></div></div><div className="panel form"><label>מוצא<input placeholder="לדוגמה: מגדל"/></label><label>יעד<input placeholder="לדוגמה: חיפה"/></label><div className="row"><label>גובה משאית (מ׳)<input placeholder="4.00"/></label><label>משקל כולל (טון)<input placeholder="15"/></label></div><button className="primary"><Map size={18}/> מצא מסלול בטוח</button></div></section>}
function Fleet(){return <section className="page"><div className="hero"><div><p className="eyebrow">FLEET</p><h1>צי הרכב</h1><p>ניהול משאיות, נהגים וסטטוס נסיעה.</p></div></div><div className="panel table"><div className="tr head"><span>משאית</span><span>נהג</span><span>סטטוס</span><span>בטיחות</span></div>{["12-345-67","45-678-90","78-901-23","34-567-81"].map((n,i)=><div className="tr" key={n}><span><Truck size={16}/> {n}</span><span>{["דוד כהן","יוסי לוי","אבי מזרחי","נועם ישראלי"][i]}</span><span className="pill">פעילה</span><span className="safe">תקין</span></div>)}</div></section>}
function Alerts(){return <section className="page"><div className="hero"><div><p className="eyebrow">SAFETY CENTER</p><h1>מרכז התראות</h1><p>התראות בטיחות ומגבלות מסלול.</p></div></div><div className="panel alert"><AlertTriangle/><div><b>התראה לדוגמה</b><p>מגבלת גובה זוהתה בהמשך המסלול. המערכת תציע מסלול חלופי.</p></div><Clock3 size={18}/></div><div className="panel alert"><ShieldCheck/><div><b>כל שאר הנסיעות תקינות</b><p>לא זוהו אירועי בטיחות נוספים.</p></div></div></section>}
